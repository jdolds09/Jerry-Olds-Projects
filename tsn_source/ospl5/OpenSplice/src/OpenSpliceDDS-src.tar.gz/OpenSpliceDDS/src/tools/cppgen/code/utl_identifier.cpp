/*
 
COPYRIGHT
 
Copyright 1992, 1993, 1994 Sun Microsystems, Inc.  Printed in the United
States of America.  All Rights Reserved.
 
This product is protected by copyright and distributed under the following
license restricting its use.
 
The Interface Definition Language Compiler Front End (CFE) is made
available for your use provided that you include this license and copyright
notice on all media and documentation and the software program in which
this product is incorporated in whole or part. You may copy and extend
functionality (but may not remove functionality) of the Interface
Definition Language CFE without charge, but you are not authorized to
license or distribute it to anyone else except as part of a product or
program developed by you or with the express written consent of Sun
Microsystems, Inc. ("Sun").
 
The names of Sun Microsystems, Inc. and any of its subsidiaries or
affiliates may not be used in advertising or publicity pertaining to
distribution of Interface Definition Language CFE as permitted herein.
 
This license is effective until terminated by Sun for failure to comply
with this license.  Upon termination, you shall destroy or return all code
and documentation for the Interface Definition Language CFE.
 
INTERFACE DEFINITION LANGUAGE CFE IS PROVIDED AS IS WITH NO WARRANTIES OF
ANY KIND INCLUDING THE WARRANTIES OF DESIGN, MERCHANTIBILITY AND FITNESS
FOR A PARTICULAR PURPOSE, NONINFRINGEMENT, OR ARISING FROM A COURSE OF
DEALING, USAGE OR TRADE PRACTICE.
 
INTERFACE DEFINITION LANGUAGE CFE IS PROVIDED WITH NO SUPPORT AND WITHOUT
ANY OBLIGATION ON THE PART OF Sun OR ANY OF ITS SUBSIDIARIES OR AFFILIATES
TO ASSIST IN ITS USE, CORRECTION, MODIFICATION OR ENHANCEMENT.
 
SUN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES SHALL HAVE NO LIABILITY WITH
RESPECT TO THE INFRINGEMENT OF COPYRIGHTS, TRADE SECRETS OR ANY PATENTS BY
INTERFACE DEFINITION LANGUAGE CFE OR ANY PART THEREOF.
 
IN NO EVENT WILL SUN OR ANY OF ITS SUBSIDIARIES OR AFFILIATES BE LIABLE FOR
ANY LOST REVENUE OR PROFITS OR OTHER SPECIAL, INDIRECT AND CONSEQUENTIAL
DAMAGES, EVEN IF SUN HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 
Use, duplication, or disclosure by the government is subject to
restrictions as set forth in subparagraph (c)(1)(ii) of the Rights in
Technical Data and Computer Software clause at DFARS 252.227-7013 and FAR
52.227-19.
 
Sun, Sun Microsystems and the Sun logo are trademarks or registered
trademarks of Sun Microsystems, Inc.
 
SunSoft, Inc.  
2550 Garcia Avenue 
Mountain View, California  94043
 
NOTE:
 
SunOS, SunSoft, Sun, Solaris, Sun Microsystems or the Sun logo are
trademarks or registered trademarks of Sun Microsystems, Inc.
 
 */

// utl_identifier - Implementation of identifiers

// To fix eCPP989 where identifiers differening only in case did not
// generate compile errors, identifier comparison and hash value methods
// were changed to use lower case identifier string. To support old
// behaviour -case compiler flag was added which sets 
// BE_Globals::case_sensitive.

#include "os_stdlib.h"
#include "os_heap.h"
#include "idl.h"
#include "idl_extern.h"
#include "xbe_globals.h"

Identifier::Identifier (const char * s, long x, long y, long z)
{
   pv_string = s;

   if (s && (s[0] == '_'))
   {
      pv_string++;
   }
};

Identifier::Identifier (const char * s)
{
   pv_string = s;

   if (s && (s[0] == '_'))
   {
      pv_string++;
   }
};

unsigned long Identifier::hash () const
{
   const long p = 1073741827L;  // prime
   int n = strlen (pv_string);
   long h = 0;
   char * str = (char*) pv_string;

   for (int i = 0; i < n; ++i, ++str)
   {
      h = (h << 2);
      h += (BE_Globals::case_sensitive) ? *str : tolower (*str);
   }

   return ((h >= 0) ? (h % p) : ( -h % p));
}

// Compare two Identifiers either case sensitive or insensitive.
// Note: not all systems support strcasecmp. 

long Identifier::compare (Identifier * o)
{
   long result;
   const char * id1 = pv_string;;
   const char * id2;

   if (o == NULL)
      return I_FALSE;

   if (pv_string == NULL || o->get_string () == NULL)
      return I_FALSE;

   id2 = o->get_string ();

   if (! BE_Globals::case_sensitive)
   {
      char * tmp;

      id1 = os_strdup (pv_string);
      id2 = os_strdup (o->get_string ());

      tmp = (char*) id1;
      while (*tmp)
      {
         *tmp = tolower (*tmp);
         tmp++;
      }
      tmp = (char*) id2;
      while (*tmp)
      {
         *tmp = tolower (*tmp);
         tmp++;
      }
   }

   result = (strcmp (id1, id2) == 0) ? I_TRUE : I_FALSE;

   if (! BE_Globals::case_sensitive)
   {
      os_free ((void*) id1);
      os_free ((void*) id2);
   }

   return result;
}

long Identifier::operator== (const Identifier & o) const
{
   Identifier * op = (Identifier*) & o;
   return ((Identifier*)this)->compare(op);
}

void Identifier::dump (ostream &o)
{
   if (pv_string)
   {
      o << pv_string;
   }
}

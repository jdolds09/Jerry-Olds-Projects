/*
 *                         OpenSplice DDS
 *
 *   This software and documentation are Copyright 2006 to 2013 PrismTech
 *   Limited and its licensees. All rights reserved. See file:
 *
 *                     $OSPL_HOME/LICENSE
 *
 *   for full copyright notice and license terms.
 *
 */
#ifndef IDL_GENCXXSTREAMS_H
#define IDL_GENCXXSTREAMS_H

#include "idl_program.h"

/* last edit on friday !!! */
idl_program idl_genCxxStreamsImplProgram (void);

#endif /* IDL_GENCXXSTREAMS_H */

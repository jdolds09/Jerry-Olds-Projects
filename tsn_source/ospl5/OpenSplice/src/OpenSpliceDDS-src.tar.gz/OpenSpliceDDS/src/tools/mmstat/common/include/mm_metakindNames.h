extern char *baseKind [];
extern char *collectionKind [];

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int main()
{
    // Variables
    string last_name;
    ofstream outfile;
    ifstream infile;

    // Get user's last name
    cout << "Please enter your last name: ";
    cin >> last_name;

    // Send user's last name to ouput file
    outfile.open("name.txt");
    outfile << last_name;
    outfile.close();

    // Read and display content from output file
    infile.open("name.txt");
    infile >> last_name;
    infile.close();

    cout << "\nYour last name is: " << last_name << endl;

    return 0;
}
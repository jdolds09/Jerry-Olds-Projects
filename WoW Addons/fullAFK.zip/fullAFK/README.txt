To start following another player:

/leech <enter player's name>

To stop following another player:

/stopleech
// This is my fucking text based adventure game bitches
#include<iostream>
#include<string>
using namespace std;

// Function Prototypes dawg
char taco_bell();
char moat();
char helmet();
string league();
char equipment();
char first_move();
char second_move();

// Main
int main()
{
// Fucking Variables Yo
	char window;
	char window2;
	char window3;
	char respects;
	char burrito;
	char fucking_moat;
	char academy;
	string champion;
	char guard;
	char first_action;
	char second_action;
	char secret_technique;
	char try_again;
	char carry_on;
	char fuck;
	char shit;
	char ass;
	char titty;
	char fart;
	char shart;
	char cock;
	char queef;
	char potato;
	char diarrhea;
	char finish;
// Intro
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t      Bared's Adventure" << endl;
	cout << "\t\t\t\t Introduction" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "Long ago in a shitty town called Arlington. There was a ginger who's hair\nburned so bright, he lead santa's sleigh when rudolph wasn't feeling so hot.\n" << endl;
	cout << "His name..... was Bared Jadley" << endl;
	cout << "\nWhat Bared didn't know was that he was about to set out on an adventure\nof a lifetime. An adventure fueled by love and full of dank ass memes." << endl;
	cout << "It all started on this infamous night....\n" << endl;
	cout << "One morning Bared was Netflixing and chilling with his gurl...... McChicken." << endl;
	cout << "Bared dozed off and when he was awoken... McChicken was gone!!!" << endl;
	cout << "Bared frantically looked everywhere for McChicken, until he noticed an open\nwindow." << endl;
// Tutorial
	cout << "\nDoes Bared check the window? (Y or N): ";
	cin >> window;
	if (window == 'y' || window == 'Y')
	{
		window2 = 'y';
		window3 = 'y';
	}
	else if (window != 'y' && window != 'Y')
	{
		cout << "This is a tutorial dumbass pick (Y): ";
		cin >> window2;
	}
	if (window2 == 'y' || window2 == 'Y')
	{
		window3 = 'y';
	}
	else if (window2 != 'y' && window2 != 'Y')
		{
			cout << "Well aren't you a little smart ass.. Pick (Y) -.- : ";
			cin >> window3;
		}	
	if (window3 != 'y' && window3 != 'Y')
		{
			cout << "Fuck you I'm picking (Y) for you." << endl;
			window = 'y';
		}
// Tutorial Complete
	cout << "\nBared inspected the window and he found that Mr. Steal Yo Gurl got his tighty\nwhities caught on the window";
	cout << " and a piece of it had been torn off." << endl;
	cout << "\nBared knew but one man who still wore tighty whities... Dennis Denoski" << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> fuck;
	cout << "\nBared started walking over to DJ's house and give him his usual bitch slap\nand take back his McChicken,";
	cout << " but as Bared was walking he thought about how\nballsy a move this was from DJ, he normally wouldn't do something so ballsy." << endl;
	cout << "\nBared stormed though DJ's door and prepared his back hand but by Bared's\nsuprise DJ fired immensely powerful bolts of energy at Bared.";
	cout << " Bared looked up\nand almost shit his pants. DJ had collected all the ancient artifacts that were all the flavors of Mountain Dew and Doritos!!!" << endl;
	cout << "\nThe artifacts made DJ omnipotent and Bared knew he was overmatched.\nBared barely escaped with his life and knew that he could not take on DJ alone." << endl;
	cout << "He needed a powerful champion that could drag childsized males like DJ with\nease,\n\nand there was only one such champion that could do the job..." << endl;
	cout << "\nHarambe." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> carry_on;
// Chapter 1
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\tChapter 1" << endl;
	cout << "\t\t\t The Search for Harambe" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "Unfortunately, Harambe was recently 360 no scoped and wasn't amongst the land\nof the living." << endl;
	cout << "\nBared needed to see Eric Van, a powerful asian wizard, to see if there was a\nway to summon Harambe from the Heaven of Legends. ";
	cout << "Eric told Bared that the only\nthing that had the power to summon gorillas was Snoop Dogg's Pimp Cane." << endl;
// Call Taco Bell
	burrito = taco_bell();
	if (burrito == 'y' || burrito == 'Y')
	{
		cout << "\nBared stopped and ate one of thier nasty ass burritos" << endl;
	}
	else
	{
		cout << "\nBared did not stop and eat at Taco Bell." << endl;
	}
	cout << "\nAfter much time, Bared had finally arrived at Snoop Dogg's Mansion." << endl;
// Call Moat (This was too much god damn work)
	fucking_moat = moat();
	while (fucking_moat == 's' || fucking_moat == 'S')
	{
		cout << "\nAre you fucking stupid? Of course Snoop Dogg's moat is infested with dick\neating piranhas." << endl;
		cout << "\nBared's dick is eaten off and slowly bleeds out." << endl;
		cout << "\nTry again? (Y or N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
		{
			return 0;
		}
		else
		{
			fucking_moat = moat();
		}
	}		
	if (burrito == 'Y' || burrito == 'y' && fucking_moat == 'j' || fucking_moat == 'J')
	{
		cout << "\nBared takes a couple steps back and jumps for it..." << endl;
		cout << "\nBared sees that he is gonna come up just short. He closes his eyes and in\nfear of death";
		cout << " he lets out a massive Taco Bell fart that propells him that extra distance he needed!" << endl;
		cout << "\nBared made it acrossed the moat!!! :D" << endl;
		cout << "\nPress (C) to Continue: ";
		cin >> shit;
	}
	else if (fucking_moat == 'j' || fucking_moat == 'J')
	{
		cout << "\nBared takes a couple steps back and jumps for it..." << endl;
		cout << "Bared comes up just short and falls in to the dick eating piranha infested moat." << endl;
		cout << "Bared's dick is eaten off and slowly bleeds out... Maybe there was something\nyou could have done before???" << endl;
		cout << "\nTry again? (Y or N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
		{
			return 0;
		}
		else
		{
			burrito = taco_bell();
			while (burrito != 'y' && burrito != 'Y')
			{
				cout << "\nHey you fuck tard, I gave you a second chance to pick yes here..." << endl;
				burrito = taco_bell();
			}
			if (burrito == 'y' || burrito == 'Y')
			{
				cout << "\nBared stopped and ate one of thier nasty ass burritos" << endl;
			}
			cout << "\nAfter much time, Bared had finally arrived at Snoop Dogg's Mansion." << endl;
			fucking_moat = moat();
			while (fucking_moat == 's' || fucking_moat == 'S')
			{
				cout << "\nAre you fucking stupid? Of course Snoop Dogg's moat is infested with dick\neating piranhas." << endl;
				cout << "\nBared's dick is eaten off and slowly bleeds out." << endl;
				fucking_moat = moat();
			}
			if (burrito == 'Y' || burrito == 'y' && fucking_moat == 'j' || fucking_moat == 'J')
			{
				cout << "\nBared takes a couple steps back and jumps for it..." << endl;
				cout << "\nBared sees that he is gonna come up just short. He closes his eyes and in\nfear of death";
				cout << " he lets out a massive Taco Bell fart that propells him that extra distance he needed!" << endl;
				cout << "\nBared made it acrossed the moat!!! :D" << endl;
				cout << "\nPress (C) to Continue: ";
				cin >> ass;
			}
		}
	}
// Moat Complete
	cout << "\nBared walked through the massive doors of Snoop's Mansion and was immediately\noverwhelmed by ";
	cout << "the smell of Marajuana. The fumes are so strong that even Bared\nis on the edge of passing out.";
	cout << " Bared knows he has but one option to keep his\nconciousness.";
	cout << " He must blast a fart that will blow away the toxic fumes, but\nthis fart would come at a great cost.";
	cout << " He knew that his fart earlier that\npropelled him over the moat was his warning fart.";
	cout << " If he were to let out a\nsimilar fart........" << endl;
	cout << "\nHe would shit his pants....." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> titty;
	cout << "\nBared did the deed and when he looked up. There he was. Snoop." << endl;
	cout << "Snoop said he had mad respect for a man that would shizzle his dizzle like\nBared did";
	cout << " and he rewarded Bared with his pimp cane!" << endl;
	cout << "\nBared walked outside and with the power of Snoop's Pimp Cane, the legend that\nis Harambe was resurected." << endl;
	cout << "\nWith his new companion and about 5 pounds of shit in the back of his pants...\nBared was ready to continue his quest." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> fart;
// Chapter 2
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\tChapter 2" << endl;
	cout << "\t\t\tAcademy Sports and Outdoors" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "The power of Harambe is so great, it sapped all the power out of Snoop Dogg's\npimp cane. Bared was planning on";
	cout << " using the pimp cane in battle but now it would\nbe useless against DJ and the power of Mountain Dew and Doritos.";
	cout << " Bared needed\nto prepare for the upcoming battle. He would do so by making three stops." << endl;
	cout << "His first destination would be Academy Sports and Outdoors. The second would be back to the asian wizard Eric Van.";
	cout << " Finally, he would stop at Subway, Eat Fresh." << endl;
	cout << "\nBared rode Harambe until he and his faithful steed arrived at Academy Sports\nand Outdoors. There he found a bat,";
	cout << " a baseball, and a foot guard. The last item he needed was a helmet that was on a very high top shelf.";
	cout << " Bared knocks the\nhelmet down from the top shelf with the baseball and it is falling to the\nground." << endl;
// Call Helmet
	academy = helmet();
	while (academy == 'c' || academy == 'C')
	{
		cout << "Bared dives and tries to catch the helmet. When he lands he breaks his\ncollarbone and he is";
		cout << " unable to complete his quest." << endl;
		cout << "\nTry Again? (Y) or (N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
		{
			return 0;
		}
		else
		academy = helmet();
	}
	if (academy == 'f' || academy == 'F')
	{
		cout << "Bared lets the helmet fall to the ground and picks it up." << endl;
	}
// Helmet Complete
	cout << "\nBared got all the equipment he needed from Academy, he was now headed to the\nlair of the Asian Wizard." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> shart;
// Chapter 3	
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\tChapter 3" << endl;
	cout << "\t\t\t    The Asian Wizard" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "Bared arrived at the wizard's lair and asked Eric if there was an ancient Asian technique that";
	cout << " could help Bared defeat DJ. The wise wizard said that there was\nsuch a technique, but first Bared";
	cout << " must defeat Eric 1v1 in a match of League of\nLegends to prove that he is worthy of the secret technique." << endl;
	cout << "\nThis was a big problem for Bared... He sucked dick at League of Legends. If he\nstood any chance against Eric, he would have to cheese him.";
	cout << " There was only one\nchampion in the game that gave Bared a chance at winning." << endl;
// Call League
	champion = league();
	while (champion != "Teemo" && champion != "teemo")
	{
		cout << "Bared played " << champion << " and got his asshole gaped by Eric." << endl;
		cout << "\nTry Again? (Y) or (N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
			return 0;
		else
			champion = league();
	}
	if (champion == "Teemo" || champion == "teemo")
	{
		cout << "Bared played " << champion << " and hid in a bush and went invisible." << endl;
	}
// League Complete
	cout << "\nAfter much searching, the old wizard could not find Bared and eventually fell\nasleep.";
	cout << " This was Bared's chance!!! He jumped out of the bush and killed the\nwizard's character!!!" << endl;
	cout << "\nBared woke up the wizard and he accpeted his defeat. After much time, Bared\nlearned the secret ancient asian technique!" << endl;
	cout << "\nBared was now Subway bound." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> cock;
// Chapter 4
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t Chapter 4" << endl;
	cout << "\t\t\t\t  Subway" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "Bared stopped at Subway and got a Meatball Sub" << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> queef;
// Chapter 5
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t Chapter 5" << endl;
	cout << "\t\t\t\tFinal Battle" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "Bared and Harambe arrived at DJ's front door. Before the battle begins, Bared\nand Harambe needed to equip themselves." << endl;
// Call Equipment
	guard = equipment();
	while (guard != 'f' && guard != 'F')
	{
		cout << "Bared equipped the helmet and Harambe equipped the foot guard" << endl;
		cout << "\nBared and Harambe bust through the door and Harambe grabs DJ by the foot and\nstarts to drag him.";
		cout << " Harambe is immediately shot in the head by a zoo keeper." << endl;
		cout << "DJ gets up and with the added power of Mountain Dew and Doritos, throws a\nfastball at Bared's foot";
		cout << " and breaks his foot. Bared is put in a wheelchair and\nhas an alergic reaction to hydrocodine." << endl;
		cout << "\nTry again? (Y) or (N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
			return 0;
		else
			guard = equipment();
	}
	if (guard == 'f' || guard == 'F')
	{
		cout << "Bared equipped the foot guard and Harambe equipped the helmet" << endl;
	}
// Equipment Complete
	cout << "\nBared and Harambe bust through the door and the battle begins." << endl;
	cout << "Press (C) to Continue: ";
	cin >> potato;
	cout << "\nDJ starts the battle by throwing a fastball at Bared's foot and the ball\ndeflects off the foot guard.";
	cout << " Harambe takes advanatage of DJ's vulnerability and grabs him by the foot and starts to drag him.";
	cout << " A wild zookeeper appears and\nshoots a bullet at Harambe. The bullet deflects off of the helmet back at the\nzookeeper and kills the zookeeper. ";
	cout << "This was Bared's chance to take out one of\nthe two sources that were powering DJ. He sprinted over to the Doritos and eats all the Doritos.";
	cout << " Bared eating the Doritios enrages DJ, and he shoots a bolt of\nenergy through the chest of Harambe.";
	cout << " DJ was now at half strength, but Bared\nwould now have to finish the fight without his faithful compainion." << endl;
	cout << "\nBared thought out his next move." << endl;
// Call First Move
	first_action = first_move();
	while (first_action == 's' || first_action == 'S')
	{
		cout << "\nBared started charging up his secret technique he learned form Eric." << endl;
		cout << "While he was charging his attack, DJ shot a bolt of energy through his chest\nand killed Bared." << endl;
		cout << "\nTry again? (Y) or (N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
			return 0;
		else
			first_action = first_move();
	}
	while (first_action == 'm' || first_action == 'M')
	{
		cout << "\nBared threw a meatball sub at DJ..." << endl;
		cout << "DJ fired a bolt of energy through Bared's chest and killed Bared." << endl;
		cout << "\nTry again? (Y) or (N): ";
		cin >> try_again;
		if (try_again == 'n' || try_again == 'N')
			return 0;
		else
		{
			first_action = first_move();
			while (first_action == 's' || first_action == 'S')
			{
				cout << "\nBared started charging up his secret technique he learned form Eric." << endl;
				cout << "While he was charging his attack, DJ shot a bolt of energy through his chest\nand killed Bared." << endl;
				cout << "\nTry again? (Y) or (N): ";
				cin >> try_again;
				if (try_again == 'n' || try_again == 'N')
					return 0;
				else
					first_action = first_move();
			}
		}
	}
	if (first_action == 'b' || first_action == 'B')
	{
		cout << "\nBared hit a ground ball to DJ. The ball took a bad hop and hit DJ right in the\nface." << endl;
	}
// First Move Complete
	cout << "\nWhile DJ was crying and dealing with a bloody nose, Bared took the opportunity\nto drink all the Mountain Dew and render DJ completely powerless." << endl;
	cout << "Bared has him right where he wants him." << endl;
// Call Second Move
	second_action = second_move();
	if (second_action == 'm' || second_action == 'M')
	{
		cout << "\nBared throws a meatball sub at DJ..." << endl;
		cout << "At this point, there is nothing DJ can do about it." << endl;
		cout << "\nPress (S) to unleash the secret technique: ";
		cin >> secret_technique;
		while (secret_technique != 's' && secret_technique != 'S')
		{
			cout << "\nPress (S) to unleash the secret technique: ";
			cin >> secret_technique;
		}
	}
	cout << "\nBared charged up his secret technique and unleashed the famed Slap of 1000\nBitches.";
	cout << " The bitch slap was so strong, it opened a rift in space and time and\nDJ was sucked in to another dimension." << endl;
	cout << "\nThe battle was over." << endl;
	cout << "\nPress (C) to Continue: ";
	cin >> diarrhea;
// Chapter 6
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t Chapter 6" << endl;
	cout << "\t\t\t      New Beginnings" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "After the battle, Bared sprinted over to Harambe to see if he was ok.";
	cout << " Harambe\ntold him that he was not meant for this world and he must return to the Heaven\nof Legends." << endl;
	cout << "\nPress (F) to Pay Respects: ";
	cin >> respects;
	while (respects != 'f' && respects != 'F')
	{
		cout << "\nIt's press (F) to Pay respects. Not (" << respects << ")." << endl;
		cout << "\nPress (F) to Pay Respects: ";
		cin >> respects;
	}
	cout << "Bared paid his repects and went to be reunited with McChicken." << endl;
	cout << "\nBared embraced McChicken and it was at this point McChicken told Bared that she left with DJ willingly!!!";
	cout << " She told Bared that she would rather die than be with him any longer." << endl;
	cout << "\nBared was furious. He wished he had the strength to unleash another Slap of\n1000 Bitches.";
	cout << " Instead, Bared devoured McChicken and started a new relationship\nwith Meatball Sub." << endl;
	cout << "\nPress (F) to Finish: ";
	cin >> finish;
	cout << "-------------------------------------------------------------------------------" << endl;
	cout << "\t\t\t\t The End" << endl;
	cout << "-------------------------------------------------------------------------------" << endl;
}

char taco_bell()
{
// Variable
	char taco;
// User Prompt
	cout << "\nSo Bared started his excursion to Snoop Dogg's Mansion, on his way there he\nsees a Taco Bell." << endl;
	cout << "\nDoes Bared stop at the Taco Bell? (Y or N): ";
	cin >> taco;
	while (taco != 'y' && taco != 'Y' && taco != 'n' && taco != 'N')
	{
		cout << "Enter (Y) or (N) dumbass: ";
		cin >> taco;
	}
	return taco;
}
char moat()
{
// Variable
	char swim_jump;
// User Prompt
	cout << "Snoop's mansion was protected by a moat and the draw bridge was up." << endl;
	cout << "\nDoes Bared try to swim across (S) the moat or try to jump it (J): ";
	cin >> swim_jump;
	while (swim_jump != 's' && swim_jump != 'S' && swim_jump != 'j' && swim_jump != 'J')
	{
		cout << "Enter (S) or (J) dumbass: ";
		cin >> swim_jump;
	}
	return swim_jump;
}
char helmet()
{
// Variable
	char collarbone;
// User Prompt
	cout << "\nDoes Bared try to catch it (C) or let it fall (F): ";
	cin >> collarbone;
	while (collarbone != 'c' && collarbone != 'C' && collarbone != 'f' && collarbone != 'F')
	{
		cout << "Enter (C) or (F) dumbass: ";
		cin >> collarbone;
	}
	return collarbone;
}
string league()
{
// Variable
	string character;
// User Prompt
	cout << "\nBared would have to play (Enter Champion Name): ";
	cin >> character;
	return character;
}
char equipment()
{
// Variable
	char equip;
// User Prompt
	cout << "\nDoes Bared wear the foot guard (F) or the helmet? (H): ";
	cin >> equip;
	while (equip != 'f' && equip != 'F' && equip != 'h' && equip != 'H')
	{
		cout << "C'mon dumbass... You've played the game long enough to know to enter\n(F) or (H): ";
		cin >> equip;
	}
	return equip;
}
char first_move()
{
// Variable
	char move;
// User Prompt
	cout << "\nDoes Bared use the Secret Technique (S), the Bat and Ball (B), or the Meatball\nSub? (M): ";
	cin >> move;
	while (move != 's' && move != 'S' && move != 'b' && move != 'B' && move != 'm' && move != 'M')
	{
		cout << "\nAt this time I'm way too tired to come up with some one liner insulting your\nintellegence.";
		cout << " Please choose (S), (B) or (M): ";
		cin >> move;
	}
	return move;
}
char second_move()
{
// Variable
	char move_two;
// User Prompt
	cout << "\nDoes Bared use the Secret Technique (S) or the Meatball Sub (M): ";
	cin >> move_two;
	while (move_two != 's' && move_two != 'S' && move_two != 'm' && move_two != 'M')
	{
		cout << "..... (S) or (M): ";
		cin >> move_two;
	}
	return move_two;
}
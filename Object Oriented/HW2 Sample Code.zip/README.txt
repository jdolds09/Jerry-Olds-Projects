To compile full credit:
make full_credit

To run full credit:
./Secret_Code_1

To compile extra credit:
make extra_credit

To run extra credit:
./Secret_Code_2
#include "Employee.h"

/*double Employee::pay(double pre_tax)
{
    return pre_tax * 0.9;
}*/

string Employee::get_name()
{
return name;
}

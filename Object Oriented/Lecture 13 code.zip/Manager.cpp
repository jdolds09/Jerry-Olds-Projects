#include "Manager.h"

double Manager::pay(double bonus)
{
    return salary / 12 + bonus;
}

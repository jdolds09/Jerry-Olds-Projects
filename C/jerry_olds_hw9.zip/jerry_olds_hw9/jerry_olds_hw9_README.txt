CSE 1320 - Intermediate Programming Fall 2017

Assignment:
Homework 9

Command line to build the assignment:

gcc jerry_olds_hw9.c -o hw9

Command line to run the assignment:

hw9 filename NumberOfLinkedLists

example:
hw9 data.dat 10
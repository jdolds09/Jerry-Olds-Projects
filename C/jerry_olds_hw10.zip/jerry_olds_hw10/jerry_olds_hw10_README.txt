CSE 1320 - Intermediate Programming Fall 2017

Assignment:
Homework 10

Command line to build the assignment:

gcc jerry_olds_hw10.c -o hw10 -lm

Command line to run the assignment:

hw10 number1 number2

example:
hw10 137 41